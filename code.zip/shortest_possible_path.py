import networkx as nx

def spp(G, start, end):
	shortest_path = nx.dijkstra_path(G, start, end)
	print(f"shortest path from {start} to {end}: {shortest_path}")
	shortest_path_length = nx.dijkstra_path_length(G, start, end)
	print(f"shortest path length from {start} to {end}: {shortest_path_length}")
    return shortest_path_length
