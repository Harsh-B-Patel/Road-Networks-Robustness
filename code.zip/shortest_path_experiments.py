import networkx as nx
import random
import statistics
import itertools
import numpy as np

class PathStats:
    __slots__ = ("path_lengths", "node_lengths", "longest_path_length",
        "longest_path", "path_with_most_nodes_amount", "path_with_most_nodes",
        "average_path_length", "average_node_length", "path_type")

    def __init__(self, path_type):
        self.path_type = path_type
        self.path_lengths = []
        self.node_lengths = []
        self.longest_path_length = 0
        self.longest_path = None
        self.path_with_most_nodes_amount = 0
        self.path_with_most_nodes = None
        self.average_path_length = None
        self.average_node_length = None

    def calc_averages(self):
        self.average_path_length = statistics.mean(self.path_lengths)
        self.average_node_length = statistics.mean(self.node_lengths)

    def print_stats(self):
        output = ""
        output += f"== {self.path_type} stats ==\n"
        output += f"longest path: {self.longest_path}, longest path length: {self.longest_path_length}\n"
        output += f"path with most nodes: {self.path_with_most_nodes}, # of nodes: {self.path_with_most_nodes_amount}\n"
        output += f"average path length: {self.average_path_length}, average node length: {self.average_node_length}\n"
        print(output)

def get_path_statistics_for_two_nodes(G, G_nodes, start, end, path_stats):
    path_length, path = nx.bidirectional_dijkstra(G, start, end)
    path_stats.path_lengths.append(path_length)
    if path_length > path_stats.longest_path_length:
        path_stats.longest_path_length = path_length
        path_stats.longest_path = path

    path_node_length = len(path)
    path_stats.node_lengths.append(path_node_length)

    if path_node_length > path_stats.path_with_most_nodes_amount:
        path_stats.path_with_most_nodes_amount = path_node_length
        path_stats.path_with_most_nodes = path

def do_shortest_path_experiments(G, critical_nodes):
    SAMPLE_COUNT = 900
    SEED = 900
    np.random.seed(SEED)
    random.seed(SEED)

    G_nodes = tuple(G.nodes)
    print("testing random node to random node (source != dest): ")
    r2r_path_stats = PathStats("random to random")

    for i in range(SAMPLE_COUNT):        
        start, end = random.sample(G_nodes, 2)
        get_path_statistics_for_two_nodes(G, G_nodes, start, end, r2r_path_stats)

    r2r_path_stats.calc_averages()
    r2r_path_stats.print_stats()

    #shortest_possible_path.spp(G, start, end)

    c2r_path_stats = PathStats("critical to random")

    # iterate through each critical node measure one by one
    # i.e. get a critical node from betweenness_centrality, then
    # get a critical node from mean_closeness_centrality, then get a
    # critical node from max_closeness_centrality, then keep doing that
    # until SAMPLE_COUNT//3 (todo explain this)
    for critical_node_iterable in itertools.islice(zip(
        critical_nodes.betweenness_centrality.keys(),
        critical_nodes.mean_closeness_centrality.keys(),
        critical_nodes.max_closeness_centrality.keys()
    ), SAMPLE_COUNT//3):
        for critical_node in critical_node_iterable:
            start = critical_node
            while True:
                end = random.choice(G_nodes)
                if start != end:
                    break

            get_path_statistics_for_two_nodes(G, G_nodes, start, end, c2r_path_stats)

    c2r_path_stats.calc_averages()
    c2r_path_stats.print_stats()

    #index = random.randrange(len(critical_nodes.betweenness_centrality))
    #start1 = list(critical_nodes.betweenness_centrality)[index]
    #end1 = random.randrange(len(G.nodes()))
    #print("\ncritical node to random node: ")
    #shortest_possible_path.spp(G, start1, end1)

NUM_EDGES_TO_REMOVE = 10
SAMPLE_COUNT = 900

class C2RStartEndProvider:
    __slots__ = ("ordered_critical_nodes", "cur_node_index")

    def __init__(self, critical_nodes):
        self.init_ordered_critical_nodes(critical_nodes)
        self.cur_node_index = 0

    def init_ordered_critical_nodes(self, critical_nodes):
        self.ordered_critical_nodes = list(itertools.chain.from_iterable(zip(
            critical_nodes.betweenness_centrality.keys(),
            critical_nodes.mean_closeness_centrality.keys(),
            critical_nodes.max_closeness_centrality.keys()
        )))

    def get_start_end_nodes(self, G_nodes):
        start = self.ordered_critical_nodes[self.cur_node_index]
        self.cur_node_index += 1
        end = random.choice(G_nodes)
        return start, end

class R2RStartEndProvider:

    def __init__(self):
        pass

    def get_start_end_nodes(self, G_nodes):
        start, end = random.sample(G_nodes, 2)
        return start, end

class EdgeAndWeight:
    __slots__ = ("edge", "weight")

    def __init__(self, edge, weight):
        self.edge = edge
        self.weight = weight

    def __repr__(self):
        return f"({self.edge}, {self.weight})"

def normalize_edge(src_node, target_node):
    if src_node > target_node:
        src_node, target_node = target_node, src_node
    return src_node, target_node

class TrafficSim:
    __slots__ = ("G", "G_nodes", "removed_edges_for_paths", "all_path_lengths_for_removing_edges", "edge_removal_func", "start_end_provider", "edge_centrality", "G_edges_weight_lookup", "output")

    def __init__(self, G, edge_removal_func, start_end_provider):
        self.G = G
        self.G_nodes = tuple(G.nodes())
        self.all_path_lengths_for_removing_edges = []
        self.removed_edges_for_paths = []
        self.edge_removal_func = edge_removal_func
        self.start_end_provider = start_end_provider
        self.calc_edge_centrality()
        self.compute_G_edges_weight_lookup()
        self.output = ""

    def compute_G_edges_weight_lookup(self):
        self.G_edges_weight_lookup = {}

        for u, v, d in self.G.edges(data=True):
            weight = d["weight"]
            self.G_edges_weight_lookup[(u, v)] = weight
            self.G_edges_weight_lookup[(v, u)] = weight

    def calc_edge_centrality(self):
        degree_centrality = nx.degree_centrality(self.G)
        self.edge_centrality = {}
        for u, v in self.G.edges:
            cur_edge_centrality = degree_centrality[u] + degree_centrality[v]
            self.edge_centrality[(u, v)] = cur_edge_centrality
            self.edge_centrality[(v, u)] = cur_edge_centrality

    def do_congestion_simulation(self):
        for i in range(SAMPLE_COUNT):
            if i % 50 == 0:
                print(f"do_congestion_simulation i: {i}")
            path_lengths_for_removing_edges = []
            removed_edges_for_path = []
            G_copy = self.G.copy()
            while True:
                start, end = self.start_end_provider.get_start_end_nodes(self.G_nodes)
                path_length, path = nx.bidirectional_dijkstra(G_copy, start, end)
                # only accept paths where the number of available edges to remove is greater than the number we need to remove
                if len(path) - 3 > NUM_EDGES_TO_REMOVE:
                    break
    
            path_lengths_for_removing_edges.append(path_length)
            #print(f"path: {path}")
            #raise RuntimeError()
    
            for i in range(NUM_EDGES_TO_REMOVE):
                edge_to_remove = self.edge_removal_func(G_copy, path, self)
                edge_to_remove_and_weight = EdgeAndWeight(edge_to_remove, G_copy.edges[edge_to_remove]["weight"])
                G_copy.remove_edge(*edge_to_remove)
                try:
                    path_length, path = nx.bidirectional_dijkstra(G_copy, start, end)
                except nx.NetworkXNoPath:
                    # if we manage to remove an edge which disconnects the graph, set
                    # the path lengths array and the removed edges array both to None
                    # to indicate an instance where the graph completely disconnected
                    path_lengths_for_removing_edges = None
                    removed_edges_for_path = None
                    break

                removed_edges_for_path.append(edge_to_remove_and_weight)
                path_lengths_for_removing_edges.append(path_length)

            self.removed_edges_for_paths.append(removed_edges_for_path)
            self.all_path_lengths_for_removing_edges.append(path_lengths_for_removing_edges)
            #cur_iteration += 1

    def calc_unreliability(self):
        #all_path_length_scores = []
        all_path_length_scores_for_num_roadblocks = []
        local_output = ""
        for i in range(NUM_EDGES_TO_REMOVE):
            all_path_length_scores_for_num_roadblocks.append([])

        num_complete_disconnections = 0

        for path_lengths_for_removing_edges in self.all_path_lengths_for_removing_edges:
            if path_lengths_for_removing_edges is None:
                num_complete_disconnections += 1
            else:
                initial_path_length = path_lengths_for_removing_edges[0]
                cur_path_length_score = 0

                for i in range(1, len(path_lengths_for_removing_edges)):
                    path_length_at_removal_i = path_lengths_for_removing_edges[i]
                    path_length_increase = ((path_length_at_removal_i - initial_path_length)/initial_path_length)
                    all_path_length_scores_for_num_roadblocks[i-1].append(path_length_increase)
                    #cur_path_length_score +=  # * 0.5 ** (i - 1)
    
                #cur_path_length_score /= NUM_EDGES_TO_REMOVE
                #all_path_length_scores.append(cur_path_length_score)

        #graph_unreliability = statistics.mean(all_path_length_scores)
        for i, path_length_scores_for_num_roadblocks in enumerate(all_path_length_scores_for_num_roadblocks, 1):
            average_distance_increase = statistics.mean(path_length_scores_for_num_roadblocks)
            local_output += f"Distance increase for roadblock count {i}: {average_distance_increase}\n"

        #output += f"graph_unreliability: {graph_unreliability}\n"
        local_output += f"Percentage of complete disconnections: {num_complete_disconnections/SAMPLE_COUNT:.4f} ({num_complete_disconnections}/{SAMPLE_COUNT})"
        print(local_output)
        self.output += f"{local_output}\n"

    def calc_unreliability_new_metric(self):
        all_path_length_scores = []
        num_complete_disconnections = 0
        local_output = ""

        for removed_edges_for_path, path_lengths_for_removing_edges in zip(self.removed_edges_for_paths, self.all_path_lengths_for_removing_edges):
            if removed_edges_for_path is None:
                num_complete_disconnections += 1
            else:
                initial_path_length = path_lengths_for_removing_edges[0]
                cur_path_length_score = 0
                cumulative_removed_edge_weights = 0

                for i in range(1, len(path_lengths_for_removing_edges)):
                    path_length_at_removal_i = path_lengths_for_removing_edges[i]
                    cumulative_removed_edge_weights += removed_edges_for_path[i-1].weight
                    cur_path_length_score += ((path_length_at_removal_i - initial_path_length)/cumulative_removed_edge_weights) # * 0.5 ** (i - 1)

                cur_path_length_score /= NUM_EDGES_TO_REMOVE
                all_path_length_scores.append(cur_path_length_score)

        graph_unreliability = statistics.mean(all_path_length_scores)
        local_output += f"Percentage increase of roadblock distance: {graph_unreliability}\n"
        #local_output += f"Percentage of complete disconnections: {num_complete_disconnections/SAMPLE_COUNT:.4f} ({num_complete_disconnections}/{SAMPLE_COUNT})\n"
        print(local_output)
        self.output += f"{local_output}\n"

    def write_output_to_file(self, title, prefix):
        self.output = f"== {title} ==\n" + self.output
        with open(f"{prefix}_general_stats.txt", "w+") as f:
            f.write(self.output)

    def write_all_path_lengths_to_file(self, prefix):
        output = ""
        output += "\n".join(f"{path_lengths_for_removing_edges}" for path_lengths_for_removing_edges in self.all_path_lengths_for_removing_edges)
        with open(f"{prefix}_all_path_lengths.txt", "w+") as f:
            f.write(output)

    def write_removed_edges_for_paths_to_file(self, prefix):
        output = ""
        output += "\n".join(f"{removed_edges_for_path}" for removed_edges_for_path in self.removed_edges_for_paths)
        with open(f"{prefix}_removed_edges_for_paths.txt", "w+") as f:
            f.write(output)

def get_random_edge_from_path(G, path, traffic_sim):
    edge_to_remove_src_node_index = random.randint(1, len(path) - 3)
    edge_to_remove_src_node = path[edge_to_remove_src_node_index]
    edge_to_remove_target_node = path[edge_to_remove_src_node_index + 1]
    return (edge_to_remove_src_node, edge_to_remove_target_node)

# Recipe from https://docs.python.org/3/library/itertools.html#itertools.pairwise
def pairwise(iterable):
    # pairwise('ABCDEFG') --> AB BC CD DE EF FG
    a, b = itertools.tee(iterable)
    next(b, None)
    return zip(a, b)

def get_max_edge_from_path(G, path, traffic_sim):
    G_edges_weight_lookup = traffic_sim.G_edges_weight_lookup
    max_edge, max_edge_weight = max((((u, v), G_edges_weight_lookup[u, v]) for u, v in pairwise(itertools.islice(path, 1, len(path) - 1))), key=lambda x: x[1])
    return max_edge

def get_chimera_edge_from_path(G, path, traffic_sim):
    edge_centrality = traffic_sim.edge_centrality
    most_critical_edge, most_critical_edge_centrality = max((((u, v), edge_centrality[(u, v)]) for u, v in pairwise(itertools.islice(path, 1, len(path) - 1))), key=lambda x: x[1])

    return most_critical_edge
    #start_node = path[0]
    #paths_for_nodes_near_start_node = nx.single_source_shortest_path(G, node, cutoff=5)

def calc_c2r_score(G, critical_nodes, edge_removal_func, filename_prefix, title):
    c2r_traffic_sim = TrafficSim(G, edge_removal_func, C2RStartEndProvider(critical_nodes))
    c2r_traffic_sim.do_congestion_simulation()
    c2r_traffic_sim.calc_unreliability()
    c2r_traffic_sim.calc_unreliability_new_metric()
    c2r_traffic_sim.write_output_to_file(title, filename_prefix)
    c2r_traffic_sim.write_removed_edges_for_paths_to_file(filename_prefix)
    c2r_traffic_sim.write_all_path_lengths_to_file(filename_prefix)

def calc_r2r_score(G, edge_removal_func, filename_prefix, title):
    r2r_traffic_sim = TrafficSim(G, edge_removal_func, R2RStartEndProvider())
    r2r_traffic_sim.do_congestion_simulation()
    r2r_traffic_sim.calc_unreliability()
    r2r_traffic_sim.calc_unreliability_new_metric()
    r2r_traffic_sim.write_output_to_file(title, filename_prefix)
    r2r_traffic_sim.write_removed_edges_for_paths_to_file(filename_prefix)
    r2r_traffic_sim.write_all_path_lengths_to_file(filename_prefix)

def seed_both_randoms(seed):
    np.random.seed(seed)
    random.seed(seed)

def do_experiment(G, critical_nodes, csv_filename_stem):
    SEED = 1800

    if True:
        seed_both_randoms(SEED)
        calc_c2r_score(G, critical_nodes, get_random_edge_from_path, f"{csv_filename_stem}_c2r", "Critical to Random using random edge removal")

    if True:
        seed_both_randoms(SEED * 2)
        calc_c2r_score(G, critical_nodes, get_max_edge_from_path, f"{csv_filename_stem}_c2r_max", "Critical to Random using greatest weight edge removal")
        
    if True:
        seed_both_randoms(SEED * 3)
        calc_c2r_score(G, critical_nodes, get_chimera_edge_from_path, f"{csv_filename_stem}_c2r_chimera", "Critical to Random using most critical edge removal")

    if True:
        seed_both_randoms(SEED * 4)
        calc_r2r_score(G, get_random_edge_from_path, f"{csv_filename_stem}_r2r", "Random to Random using random edge removal")

    if True:
        seed_both_randoms(SEED * 5)
        calc_r2r_score(G, get_max_edge_from_path, f"{csv_filename_stem}_r2r_max", "Random to Random using greatest weight edge removal")

    if True:
        seed_both_randoms(SEED * 6)
        calc_r2r_score(G, get_chimera_edge_from_path, f"{csv_filename_stem}_r2r_chimera", "Random to Random using most critical edge removal")


    #print(f"nx.is_connected(G): {nx.is_connected(G)}")
    #G_nodes = tuple(G.nodes)
    #print("testing random node to random node (source != dest): ")
    #
    #for i in range(SAMPLE_COUNT):        
    #    start, end = random.sample(G_nodes, 2)
    #    get_path_statistics_for_two_nodes(G, G_nodes, start, end, r2r_path_stats)
    #    


