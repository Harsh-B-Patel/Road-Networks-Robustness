import pathlib
import threading
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import collections
import time
import pickle
import random
import math
import statistics
import multiprocessing as mp

class CriticalNodes:
    __slots__ = ("betweenness_centrality", "mean_closeness_centrality", "max_closeness_centrality")

    def __init__(self, betweenness_centrality, mean_closeness_centrality, max_closeness_centrality):
        self.betweenness_centrality = betweenness_centrality
        self.mean_closeness_centrality = mean_closeness_centrality
        self.max_closeness_centrality = max_closeness_centrality

def reverse_sort_dict(d):
    return {k: v for k, v in sorted(d.items(), key=lambda item: item[1], reverse=True)}

def calc_betweenness_centrality(G):
    print("Betweenness centrality start")
    start_time = time.time()
    betweenness_centrality = nx.betweenness_centrality(G, k=1500, weight="weight")
    end_time = time.time()
    print(f"Betweenness centrality end. time: {end_time - start_time}")

    sorted_betweenness_centrality = reverse_sort_dict(betweenness_centrality)
    return sorted_betweenness_centrality

def calculate_mean_max_closeness_centrality(G):
    print("Closeness centrality start")
    start_time = time.time()

    all_mean_closeness_centralities = {}
    all_max_closeness_centralities = {}

    for i, src_node in enumerate(G.nodes):
        if i % 100 == 0:
            print(f"closeness centrality iteration: {i}")
        distances = nx.single_source_dijkstra_path_length(G, src_node, weight="weight")
        all_mean_closeness_centralities[src_node] = 1/statistics.fmean(distances.values())
        all_max_closeness_centralities[src_node] = 1/max(distances.values())

    end_time = time.time()
    print(f"Closeness centrality end. time: {end_time - start_time}")

    #all_mean_closeness_centralities_sorted = sorted(
    
    return reverse_sort_dict(all_mean_closeness_centralities), reverse_sort_dict(all_max_closeness_centralities)

def split_list(a, n):
    k, m = divmod(len(a), n)
    return [a[i*k+min(i, m):(i+1)*k+min(i+1, m)] for i in range(n)]

def calculate_mean_max_closeness_centrality_partial(process_arg):
    G = process_arg.G
    thread_index = process_arg.thread_index
    nodes_subset = process_arg.nodes_subset

    partial_mean_closeness_centralities = {}
    partial_max_closeness_centralities = {}

    for i, src_node in enumerate(nodes_subset):
        if i % 100 == 0:
            print(f"ti{thread_index}: closeness centrality iteration: {i}")

        distances = nx.single_source_dijkstra_path_length(G, src_node, weight="weight")
        partial_mean_closeness_centralities[src_node] = 1/statistics.fmean(distances.values())
        partial_max_closeness_centralities[src_node] = 1/max(distances.values())

    return (partial_mean_closeness_centralities, partial_max_closeness_centralities)

class ProcessArg:
    __slots__ = ("G", "thread_index", "nodes_subset")

    def __init__(self, G, thread_index, nodes_subset):
        self.G = G
        self.thread_index = thread_index
        self.nodes_subset = nodes_subset

def calculate_mean_max_closeness_centrality_threaded(G):
    print("Closeness centrality start")
    start_time = time.time()
    NUM_THREADS = 8

    G_nodes = list(G.nodes)

    partitioned_nodes = split_list(G_nodes, NUM_THREADS)
    process_args = [ProcessArg(G.copy(), i, nodes_subset) for i, nodes_subset in enumerate(partitioned_nodes)]

    with mp.Pool(processes=NUM_THREADS) as p:
        process_results = p.map(calculate_mean_max_closeness_centrality_partial, process_args, chunksize=1)

    print("Done process!")

    all_mean_closeness_centralities = {}
    all_max_closeness_centralities = {}

    for process_result in process_results:
        partial_mean_closeness_centralities, partial_max_closeness_centralities = process_result
        all_mean_closeness_centralities.update(partial_mean_closeness_centralities)
        all_max_closeness_centralities.update(partial_max_closeness_centralities)

    end_time = time.time()
    print(f"Closeness centrality end. time: {end_time - start_time}")

    return reverse_sort_dict(all_mean_closeness_centralities), reverse_sort_dict(all_max_closeness_centralities)

def calculate_critical_nodes(G, csv_filename_stem):
    saved_critical_nodes_filepath = pathlib.Path(f"{csv_filename_stem}.pickle")

    if saved_critical_nodes_filepath.is_file():
        with open(saved_critical_nodes_filepath, "rb") as f:
            return pickle.load(f)
    else:
        betweenness_centrality = calc_betweenness_centrality(G)
        mean_closeness_centrality, max_closeness_centrality = calculate_mean_max_closeness_centrality_threaded(G)
        critical_nodes = CriticalNodes(betweenness_centrality, mean_closeness_centrality, max_closeness_centrality)
        with open(saved_critical_nodes_filepath, "wb+") as f:
            pickle.dump(critical_nodes, f, protocol=pickle.HIGHEST_PROTOCOL)

        return critical_nodes
