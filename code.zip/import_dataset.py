import networkx as nx
import matplotlib.pyplot as plt
import collections
import pickle
import random
import critical
import multiprocessing as mp
import shortest_path_experiments
import argparse
import pathlib

def main(csv_filename):
    print("ok")
    G = nx.read_weighted_edgelist(csv_filename, delimiter=",", nodetype=int)
    print("okread")

    Gcc = G.subgraph(max(nx.connected_components(G)))
    print(f"num nodes: {len(G.nodes())}, num edges: {len(G.edges())}")
    print(f"Gcc num nodes: {len(Gcc.nodes())}, Gcc num edges: {len(Gcc.edges())}")

    csv_filename_stem = pathlib.Path(csv_filename).stem
    critical_nodes = critical.calculate_critical_nodes(G, csv_filename_stem)
    # prints out the 10 most critical nodes of each measure
    print(tuple(critical_nodes.betweenness_centrality.items())[:10])
    print(tuple(critical_nodes.mean_closeness_centrality.items())[:10])
    print(tuple(critical_nodes.max_closeness_centrality.items())[:10])
    
    if False:
        shortest_path_experiments.do_shortest_path_experiments(G, critical_nodes)

    if True:
        shortest_path_experiments.do_experiment(G, critical_nodes, csv_filename_stem)

    #calculate spp
    #start = random.randrange(len(G.nodes()))
    #end = random.randrange(len(G.nodes()))
    #print("\nrandom node to random node: ")
    #shortest_possible_path.spp(G, start, end)
    #
    #index = random.randrange(len(critical_nodes.betweenness_centrality))
    #start1 = list(critical_nodes.betweenness_centrality)[index]
    #end1 = random.randrange(len(G.nodes()))
    #print("\ncritical node to random node: ")
    #shortest_possible_path.spp(G, start1, end1)

    #cant draw large files
    if False:
        nx.draw(Gcc,with_labels=True)
        print("okdraw")
        plt.show()
    #can only draw small graph

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument("-f", "--filename", dest="csv_filename", default="SJ.csv")
    args = ap.parse_args()
    main(args.csv_filename)

